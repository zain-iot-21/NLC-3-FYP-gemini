# FYP_Fast_API_M.-Abubakar-Raza


A water quality assesment app developed using the bunch of libraries. It identifies the quality of components required
for better health of plants and also supports yours queries through chatbot.............
